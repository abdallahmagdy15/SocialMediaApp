$("#encryptBtn").on("click", function () {
    var msg, key;
    msg = $("#txt").val();
    msg = msg.toUpperCase();
    key = $("#key").val();
    var msgKey=[];
    var n = msg.length;
    var m = key.length;
    var res="";
    for (var i = 0; i < n; i++) {
        msgKey[i] = key[i % m];
    }
    for (var i = 0; i < n; i++) {
        var x = (msg[i].charCodeAt(0) + msgKey[i].charCodeAt(0)) % 26;
        x += 65;
        res += String.fromCharCode(x);
    }
    $("#encrypted").html(res);
});

