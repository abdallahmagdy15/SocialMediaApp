$("#encryptBtn").on("click", function () {
    var rule1 = (Number)($("#r1").val())
        , rule2 = (Number)($("#r2").val())
        , rule3 = (Number)($("#r3").val());
    var text = $("#txt").val();
    text = text.toUpperCase();
    var res = "";
    for (var i = 0; i < text.length; i++) {
        if ((i + 4) % 3 == 1) {
            var temp = text[i];
            temp = String.fromCharCode(temp.charCodeAt(0) + rule1);
            res += temp;
        }
        else if ((i + 4) % 3 == 2) {
            var temp = text[i];
            temp = String.fromCharCode(temp.charCodeAt(0) + rule2);
            res += temp;
        }
        else {
            var temp = text[i];
            temp = String.fromCharCode(temp.charCodeAt(0) + rule3);
            res += temp;
        }
    }
    $("#encrypted").html(res);
});

