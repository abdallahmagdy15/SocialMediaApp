#include <iostream>
#include <algorithm>
#include <set>
using namespace std;

int main()
{
    string key="", txt="";
    cout << "enter text: ";
    cin >> txt;
    cout <<endl<< "enter key: ";
    cin>> key;
    for (auto & c: key)
        c = toupper(c);
    for (auto & c: txt)
        c = toupper(c);

    //replace J with I in key then txt
    for(int i =0; i<key.size(); i++)
    {
        if(key[i]=='J')
            key[i]='I';
    }
    for(int i =0; i<txt.size(); i++)
    {
        if(txt[i]=='J')
            txt[i]='I';
    }
    char arr[5][5]= {};
    int alphaCounter=65;


    //store key to remove duplicates
    set<char> keyUnique =set<char>();
    for (int i=0; i<key.size() ; i++)
    {
        keyUnique.insert(key[i]);
    }

    //iterate on matrix to fill with key & alphabet chars
    int k_i = 0;
    for(int i=0; i<5; i++)
    {
        for(int j=0; j<5; j++)
        {
            if(k_i<key.size())//check if remaining chars in key
            {
                if(key[k_i] == 'I' || key[k_i] == 'J')
                    arr[i][j] ='I';
                else
                    arr[i][j]=key[k_i];
                k_i++;
            }
            else
            {
                //check alpha char is mentioned before
                while( keyUnique.find((char)alphaCounter) != keyUnique.end() || (char)alphaCounter == 'J')
                    alphaCounter++; //skip char
                arr[i][j]= (char)alphaCounter;
                alphaCounter++;
            }

        }
    }

    //insert x between same pair of chars
    char last='@';
    string tmpTXT="";
    for (int i=0; i<txt.size() ; i++)
    {
        if(txt[i] == last)
            tmpTXT = tmpTXT + "X" + txt[i];
        else
            tmpTXT += txt[i];
        last =txt[i];
    }
    txt= tmpTXT;
    if(txt.size() % 2 != 0)
        txt+='X'; //make length of text even
    string res="";
    pair<char,char> txtPair;
    pair< pair<int,int>, pair<int,int> > pairCoordinates;
    for(int i=0; i<txt.size() ; i+=2)
    {
        //set first
        txtPair.first = txt[i];
        //set second
        txtPair.second = txt[i+1];
        //get pair coordinates
        for(int i=0; i<5; i++)
        {
            for(int j=0; j<5; j++)
            {
                if(arr[i][j]== txtPair.first)
                {
                    pairCoordinates.first.first = i;
                    pairCoordinates.first.second = j;
                }
                else if(arr[i][j]==txtPair.second)
                {
                    pairCoordinates.second.first = i;
                    pairCoordinates.second.second = j;
                }
            }
        }
        //check if chars of pair in same row or col
        if(pairCoordinates.first.first == pairCoordinates.second.first )
        {
            res+= arr[ pairCoordinates.first.first ][ (pairCoordinates.first.second +6)%5 ];//get first shifted char
            res+= arr[ pairCoordinates.second.first ][ (pairCoordinates.second.second+6)%5 ];//get second shifted char
        }
        else if(pairCoordinates.first.second == pairCoordinates.second.second )
        {
            res+= arr[ (pairCoordinates.first.first +6)%5 ][ pairCoordinates.first.second ];//get first shifted char
            res+= arr[ (pairCoordinates.second.first +6)%5 ][ pairCoordinates.second.second ];//get second shifted char
        }
        else
        {
            //get shifted chars of pair
            res+= arr[ pairCoordinates.first.first ][ pairCoordinates.second.second ];//get first shifted char
            res+= arr[ pairCoordinates.second.first ][ pairCoordinates.first.second ];//get second shifted char
        }

    }
    cout << res  << endl;
    return 0;
}
